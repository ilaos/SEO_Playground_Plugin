<?php
/**
 * AlmaSEO Locked Feature UI Helper
 *
 * Provides UI components for displaying locked Pro features to Free tier users.
 * This creates an upsell opportunity while keeping menu items visible.
 *
 * @package AlmaSEO
 * @since 6.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Render a locked feature screen for Pro-only features
 *
 * This function displays a professional lock screen with an upgrade CTA
 * when a Free tier user accesses a Pro-only feature page.
 *
 * @param string $feature_name Optional custom feature name to display
 * @param string $description Optional custom description text
 * @param string $upgrade_url Optional custom upgrade URL
 */
if (!function_exists('almaseo_render_locked_feature')) {
function almaseo_render_locked_feature( $feature_name = '', $description = '', $upgrade_url = '' ) {
    // Default values
    if ( empty( $feature_name ) ) {
        $feature_name = 'This Feature';
    }

    if ( empty( $description ) ) {
        $description = 'Upgrade to AlmaSEO Pro to unlock this feature and gain access to advanced SEO tools.';
    }

    if ( empty( $upgrade_url ) ) {
        $upgrade_url = 'https://almaseo.com/pro';
    }

    // Enqueue dashicons if not already enqueued
    wp_enqueue_style( 'dashicons' );

    // Inline CSS for the locked feature screen
    almaseo_locked_feature_styles();

    // Render the locked screen HTML
    ?>
    <div class="wrap almaseo-admin-page">
        <div class="almaseo-locked-feature">
            <div class="almaseo-locked-inner">
                <span class="almaseo-lock-icon dashicons dashicons-lock"></span>
                <h2><?php echo esc_html( $feature_name ); ?> is a Pro Feature</h2>
                <p class="almaseo-locked-description">
                    <?php echo esc_html( $description ); ?>
                </p>

                <div class="almaseo-locked-benefits">
                    <h3>Pro Features Include:</h3>
                    <ul>
                        <li><span class="dashicons dashicons-yes"></span> Bulk Metadata Editor for mass updates</li>
                        <li><span class="dashicons dashicons-yes"></span> WooCommerce SEO Optimization</li>
                        <li><span class="dashicons dashicons-yes"></span> Internal Links Auto-Insertion</li>
                        <li><span class="dashicons dashicons-yes"></span> Content Refresh Drafts & Queue</li>
                        <li><span class="dashicons dashicons-yes"></span> E-E-A-T Enforcement & Schema Drift Monitor</li>
                        <li><span class="dashicons dashicons-yes"></span> Featured Snippet Targeting</li>
                        <li><span class="dashicons dashicons-yes"></span> Priority Support & Updates</li>
                    </ul>
                </div>

                <div class="almaseo-locked-actions">
                    <a href="<?php echo esc_url( $upgrade_url ); ?>" class="button button-primary button-hero" target="_blank">
                        <span class="dashicons dashicons-unlock"></span>
                        Upgrade to Pro
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=seo-playground' ) ); ?>" class="button button-secondary">
                        Back to Overview
                    </a>
                </div>

                <p class="almaseo-locked-footer">
                    <small>
                        Already have a Pro license?
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=almaseo-settings' ) ); ?>">Activate it here</a>
                    </small>
                </p>
            </div>
        </div>
    </div>
    <?php
}
} // end function_exists guard: almaseo_render_locked_feature

/**
 * Output inline CSS for locked feature screens
 *
 * This function outputs the CSS needed for the locked feature UI.
 * It's called automatically by almaseo_render_locked_feature().
 */
if (!function_exists('almaseo_locked_feature_styles')) {
function almaseo_locked_feature_styles() {
    static $styles_printed = false;

    // Only print styles once per page load
    if ( $styles_printed ) {
        return;
    }

    $styles_printed = true;

    ?>
    <style>
        .almaseo-locked-feature {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 500px;
            margin: 20px 0;
            text-align: center;
            border: 2px solid #e0e0e0;
            background: #fafafa;
            background: linear-gradient(135deg, #fafafa 0%, #f0f0f0 100%);
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .almaseo-locked-inner {
            max-width: 600px;
            padding: 60px 40px;
        }

        .almaseo-lock-icon {
            font-size: 80px;
            width: 80px;
            height: 80px;
            color: #999;
            margin: 0 auto 20px;
            display: block;
            opacity: 0.7;
        }

        .almaseo-locked-feature h2 {
            font-size: 28px;
            margin: 0 0 15px;
            color: #333;
            font-weight: 600;
        }

        .almaseo-locked-description {
            font-size: 16px;
            color: #666;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .almaseo-locked-benefits {
            background: #fff;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 25px;
            margin: 30px 0;
            text-align: left;
        }

        .almaseo-locked-benefits h3 {
            margin: 0 0 15px;
            font-size: 18px;
            color: #333;
            text-align: center;
        }

        .almaseo-locked-benefits ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .almaseo-locked-benefits li {
            padding: 8px 0;
            color: #555;
            font-size: 14px;
            display: flex;
            align-items: center;
        }

        .almaseo-locked-benefits li .dashicons {
            color: #46b450;
            margin-right: 10px;
            font-size: 18px;
            width: 18px;
            height: 18px;
        }

        .almaseo-locked-actions {
            margin: 30px 0 20px;
        }

        .almaseo-locked-actions .button {
            margin: 0 5px;
        }

        .almaseo-locked-actions .button-hero {
            padding: 12px 30px;
            height: auto;
            font-size: 16px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .almaseo-locked-actions .button-primary {
            background: #2271b1;
            border-color: #2271b1;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .almaseo-locked-actions .button-primary:hover {
            background: #135e96;
            border-color: #135e96;
            transform: translateY(-1px);
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.15);
        }

        .almaseo-locked-actions .button .dashicons {
            font-size: 20px;
            width: 20px;
            height: 20px;
        }

        .almaseo-locked-footer {
            margin-top: 20px;
            color: #666;
        }

        .almaseo-locked-footer a {
            color: #2271b1;
            text-decoration: none;
        }

        .almaseo-locked-footer a:hover {
            text-decoration: underline;
        }

        /* Responsive adjustments */
        @media (max-width: 782px) {
            .almaseo-locked-inner {
                padding: 40px 20px;
            }

            .almaseo-locked-feature h2 {
                font-size: 24px;
            }

            .almaseo-locked-actions .button {
                display: block;
                margin: 10px 0;
                width: 100%;
            }
        }
    </style>
    <?php
}
} // end function_exists guard: almaseo_locked_feature_styles

/**
 * Get feature-specific locked screen content
 *
 * Returns customized content for specific Pro features.
 * This allows each feature to have tailored messaging.
 *
 * @param string $feature The feature identifier
 * @return array Array with 'name', 'description', and 'url' keys
 */
if (!function_exists('almaseo_get_locked_feature_content')) {
function almaseo_get_locked_feature_content( $feature ) {
    $content = array(
        'bulkmeta' => array(
            'name'        => 'Bulk Metadata Editor',
            'description' => 'Update SEO titles, descriptions, and metadata across multiple posts at once. Save hours with batch editing capabilities.',
            'url'         => 'https://almaseo.com/pro#bulkmeta',
        ),
        'woocommerce' => array(
            'name'        => 'WooCommerce SEO',
            'description' => 'Optimize your WooCommerce store with product schema markup, optimized sitemaps, and advanced eCommerce SEO features.',
            'url'         => 'https://almaseo.com/pro#woocommerce',
        ),
        'evergreen_advanced' => array(
            'name'        => 'Advanced Evergreen Features',
            'description' => 'Access advanced filtering, bulk operations, and enhanced reporting for your evergreen content strategy.',
            'url'         => 'https://almaseo.com/pro#evergreen',
        ),
        'schema_advanced' => array(
            'name'        => 'Advanced Schema Options',
            'description' => 'Unlock advanced schema types, custom properties, and enhanced structured data capabilities.',
            'url'         => 'https://almaseo.com/pro#schema',
        ),
        'optimization_dataforseo' => array(
            'name'        => 'DataForSEO Integration',
            'description' => 'Access real-time keyword data, search volume, difficulty scores, and competitive analysis with DataForSEO integration.',
            'url'         => 'https://almaseo.com/pro#dataforseo',
        ),
        'internal_links' => array(
            'name'        => 'Internal Links',
            'description' => 'Build a stronger internal linking structure without editing a single post. Create keyword-to-page rules and AlmaSEO automatically inserts the right links when visitors view your content. Built-in guardrails prevent over-linking, and your original content is never modified.',
            'url'         => 'https://almaseo.com/pro#internal-links',
        ),
        'refresh_drafts' => array(
            'name'        => 'Content Refresh',
            'description' => 'Let AlmaSEO suggest improvements to your existing posts. Compare the proposed updates against your live content section by section, keep the changes you like, and apply them with one click. WordPress revisions are saved automatically so you can always roll back.',
            'url'         => 'https://almaseo.com/pro#content-refresh',
        ),
        'refresh_queue' => array(
            'name'        => 'Refresh Queue',
            'description' => 'Automatically prioritize which content to refresh next based on business value, traffic trends, conversion potential, and opportunity size. Focus your team on the pages that will have the biggest impact.',
            'url'         => 'https://almaseo.com/pro#refresh-queue',
        ),
        'date_hygiene' => array(
            'name'        => 'Date Hygiene Scanner',
            'description' => 'Scan your content for stale year references, outdated prices, and time-decay problems that quietly erode trust. Get a focused worklist of exactly what to fix, with suggested replacements.',
            'url'         => 'https://almaseo.com/pro#date-hygiene',
        ),
        'eeat_enforcement' => array(
            'name'        => 'E-E-A-T Enforcement',
            'description' => 'Scan your content for missing trust signals: author attribution, credentials, biographical info, author schema, and citation links. Build the Experience, Expertise, Authoritativeness, and Trustworthiness that Google looks for.',
            'url'         => 'https://almaseo.com/pro#eeat',
        ),
        'gsc_monitor' => array(
            'name'        => 'GSC Monitor',
            'description' => 'Track indexation drift, rich result changes, and snippet rewrites detected from your Google Search Console data. Get alerted when Google drops pages from the index, removes rich results, or rewrites your titles and descriptions.',
            'url'         => 'https://almaseo.com/pro#gsc-monitor',
        ),
        'orphan_detection' => array(
            'name'        => 'Orphan Page Detection',
            'description' => 'Find pages with no internal links pointing to them. Discover orphan pages invisible to search crawlers, identify weak pages with too few links, and detect hub candidates that could become cornerstone content with better linking.',
            'url'         => 'https://almaseo.com/pro#orphan-detection',
        ),
        'schema_drift' => array(
            'name'        => 'Schema Drift Monitor',
            'description' => 'Detect when structured data (JSON-LD) on your pages changes unexpectedly after plugin updates, theme switches, or other site changes. Capture baselines, scan for drift, and get alerted when schemas are removed, modified, or broken.',
            'url'         => 'https://almaseo.com/pro#schema-drift',
        ),
        'snippet_targeting' => array(
            'name'        => 'Featured Snippet Targeting',
            'description' => 'Win featured snippets by targeting queries where you rank on page 1 but don\'t hold position zero. Draft snippet-optimized content in paragraph, list, table, or definition format and apply it to your posts with one click.',
            'url'         => 'https://almaseo.com/pro#snippet-targets',
        ),
    );

    if ( isset( $content[ $feature ] ) ) {
        return $content[ $feature ];
    }

    // Default fallback
    return array(
        'name'        => '',
        'description' => '',
        'url'         => 'https://almaseo.com/pro',
    );
}
} // end function_exists guard: almaseo_get_locked_feature_content

/**
 * Render a feature-specific locked screen
 *
 * This is a convenience wrapper that automatically loads
 * feature-specific content for the locked screen.
 *
 * @param string $feature The feature identifier from almaseo_feature_available()
 */
if (!function_exists('almaseo_render_feature_locked')) {
function almaseo_render_feature_locked( $feature ) {
    $content = almaseo_get_locked_feature_content( $feature );

    almaseo_render_locked_feature(
        $content['name'],
        $content['description'],
        $content['url']
    );
}
} // end function_exists guard: almaseo_render_feature_locked
